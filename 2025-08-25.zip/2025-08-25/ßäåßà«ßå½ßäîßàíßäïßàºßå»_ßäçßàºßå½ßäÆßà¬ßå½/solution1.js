// https://school.programmers.co.kr/learn/courses/30/lessons/181845?language=javascript

// 정수 n이 주어질 때, n을 문자열로 변환하여 return하도록 solution 함수를 완성해주세요.

function solution(n) {
    return String(n);
}

console.log(solution(123));	// "123"
console.log(solution(2573));	// "2573"